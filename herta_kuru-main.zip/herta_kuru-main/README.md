﻿

<div align="center"><img src="img/hertaa_github.gif"></div>

<div align="center"><p>The website for Herta, the cutest genius Honkai: Star Rail character out there!</p>
<p>献给崩坏：星穹铁道最可爱的天才黑塔酱</p></div>

# Herta Kuru | 黑塔转圈圈 | ヘルタクルへ
[Home Page | 主页 | ホーム ページ (Netlify)](https://herta.ft2.ltd/)
[(BACKUP: via GitHub Pages)](https://duiqt.github.io/herta_kuru/)

Herta gif and art made by | 黑塔 gif 绘画者 : [@Seseren_kr](https://twitter.com/Seseren_kr) 

The art the relevant copyright of Honkai: Star Rail belongs to miHoYo/HoYoverse.

角色版权归米哈游所有。
***
Contributers | 贡献者:

<a href="https://github.com/duiqt/herta_kuru/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=duiqt/herta_kuru" />
</a>
